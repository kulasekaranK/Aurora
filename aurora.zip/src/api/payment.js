import axios from 'axios'
import { apiClient } from './auth.js'
import { RAZORPAY_CONFIG } from '../config/razorpay.js'

// USD → INR only for Razorpay test checkout display
const USD_TO_INR = 83

export const loadRazorpayScript = () => {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true)
      return
    }
    const script = document.createElement('script')
    script.src = 'https://checkout.razorpay.com/v1/checkout.js'
    script.onload = () => resolve(true)
    script.onerror = () => resolve(false)
    document.body.appendChild(script)
  })
}

// Create a Razorpay order with payment_capture: 0 (authorize only)
// Called directly from frontend since this is a test storefront (no backend)
export const createRazorpayOrder = async (amountINR) => {
  const amountInPaise = Math.round(amountINR * 100)
  const credentials = btoa(`${RAZORPAY_CONFIG.KEY_ID}:${RAZORPAY_CONFIG.KEY_SECRET}`)

  const res = await fetch('/razorpay-api/v1/orders', {  // ← proxy path, not direct URL
    method: 'POST',
    headers: {
      'Authorization': `Basic ${credentials}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      amount: amountInPaise,
      currency: 'INR',
      payment_capture: 0,
      notes: {
        capture_window: '7days',  // informational only
        source: 'Aurora Storefront'
      }
    })
  })

  if (!res.ok) {
    const err = await res.json()
    throw new Error(err?.error?.description || 'Failed to create Razorpay order')
  }

  return res.json()
}

export const openRazorpayCheckout = async ({
  amount,
  orderId,
  customerInfo,
  onSuccess,
  onFailure
}) => {
  const amountInINR = amount * USD_TO_INR

  let razorpayOrderId = null

  // Create order with payment_capture: 0 so payment stays "Authorized"
  try {
    const order = await createRazorpayOrder(amountInINR)
    razorpayOrderId = order.id
  } catch (err) {
    onFailure({ message: `Could not create Razorpay order: ${err.message}` })
    return
  }

  const options = {
    key: RAZORPAY_CONFIG.KEY_ID,
    amount: Math.round(amountInINR * 100),
    currency: 'INR',
    name: RAZORPAY_CONFIG.COMPANY_NAME,
    description: `Order Payment - ${orderId || 'Aurora Order'}`,
    order_id: razorpayOrderId,   // ← Linking order makes capture:0 take effect
    prefill: {
      name: `${customerInfo.firstName} ${customerInfo.lastName}`.trim(),
      email: customerInfo.email,
      contact: customerInfo.phone || '9999999999'
    },
    theme: {
      color: RAZORPAY_CONFIG.THEME_COLOR
    },
    handler: function (response) {
      onSuccess({
        paymentToken: response.razorpay_payment_id,
        razorpayOrderId: response.razorpay_order_id || razorpayOrderId,
        signature: response.razorpay_signature || null,
        gateway: 'RAZORPAY',
        status: 'AUTHORIZED',
        amountUSD: amount,
        amountINR: amountInINR,
        raw: response
      })
    },
    modal: {
      ondismiss: function () {
        onFailure({ message: 'Payment popup closed by customer' })
      },
      confirm_close: true
    }
  }

  const rzp = new window.Razorpay(options)

  rzp.on('payment.failed', function (response) {
    onFailure({
      message: response?.error?.description || 'Payment authorization failed',
      code: response?.error?.code,
      raw: response?.error
    })
  })

  rzp.open()
}

export const storePaymentMethodInOMS = async ({
  orderNo,
  paymentToken,
  amount,
  customerInfo
}) => {
  // Expiry date 30 days from now (required for OMS to accept authorization)
  const expiryDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    .toISOString().split('T')[0]  // "YYYY-MM-DD"

  const payload = {
    OrderNo: orderNo,
    EnterpriseCode: 'Aurora',
    DocumentType: '0001',
    PaymentStatus: 'AUTHORIZED',
    PaymentMethods: {
      PaymentMethod: [{
        PaymentType: 'CREDIT_CARD',
        PaymentReference1: paymentToken,
        PaymentReference2: 'RAZORPAY',
        PaymentReference3: 'AUTHORIZED',
        DisplayCreditCardNo: '****',
        CreditCardNo: paymentToken,
        SvcNo: paymentToken,
        RequestedChargeAmount: amount.toFixed(2),
        MaxChargeLimit: amount.toFixed(2),
        UnlimitedCharges: 'N',

        // Authorization fields
        AuthorizationID: paymentToken,
        AuthorizationCode: 'RAZORPAY_AUTH',
        AuthorizationAmount: amount.toFixed(2),
        AuthorizationExpirationDate: expiryDate,  // ← required to clear Await Auth

        PersonInfoBillTo: {
          FirstName: customerInfo.firstName,
          LastName: customerInfo.lastName,
          EMailID: customerInfo.email,
          DayPhone: customerInfo.phone || ''
        },

        PaymentDetailsList: {
          PaymentDetails: [{
            ChargeType: 'AUTHORIZATION',
            TranAmount: amount.toFixed(2),          // ← sets Open Authorized at header
            RequestAmount: amount.toFixed(2),
            ProcessedAmount: amount.toFixed(2),
            AuthorizationID: paymentToken,
            AuthorizationCode: 'RAZORPAY_AUTH',
            AuthorizationExpirationDate: expiryDate,

            InternalReasonCode: 'SUCCESS'
          }]
        }
      }]
    }
  }

  const res = await apiClient.post('/invoke/changeOrder', payload)
  return res.data
}

// IMPORTANT:
// recordExternalCharges uses PaymentMethod -> PaymentDetailsList -> PaymentDetails
// The API may return empty body / non-JSON on success.
// We treat HTTP 2xx as success.
export const recordAuthorizationInOMS = async ({
  orderNo,
  paymentToken,
  amount,
  customerInfo
}) => {
  const payload = {
    OrderNo: orderNo,
    EnterpriseCode: 'Aurora',
    DocumentType: '0001',
    PaymentMethod: {
      PaymentType: 'CREDIT_CARD',
      PaymentReference1: paymentToken,
      PaymentReference2: 'RAZORPAY',
      PaymentReference3: 'AUTHORIZED',
      DisplayCreditCardNo: '****',
      PersonInfoBillTo: {
        FirstName: customerInfo.firstName,
        LastName: customerInfo.lastName,
        EMailID: customerInfo.email,
        DayPhone: customerInfo.phone || ''
      },
      PaymentDetailsList: {
        PaymentDetails: [{
          ChargeType: 'AUTHORIZATION',
          RequestAmount: amount.toFixed(2),
          ProcessedAmount: amount.toFixed(2),
          AuthorizationID: paymentToken,
          AuthorizationCode: 'RAZORPAY_AUTH',
          HoldAgainstBook: 'Y',
          RequestProcessed: 'Y'
        }]
      }
    },
    Memo: 'Razorpay authorization token stored by storefront'
  }

  const token = localStorage.getItem('aurora_jwt')

  const res = await axios.post(
    '/smcfs/restapi/invoke/recordExternalCharges',
    payload,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'ibm-oms-app': 'storefront',
        'Content-Type': 'application/json'
      },
      responseType: 'text',
      transformResponse: [(data) => data],
      validateStatus: (status) => status >= 200 && status < 300
    }
  )

  return res.data
}

export const saveAuthorizedPaymentToOMS = async ({
  orderNo,
  paymentToken,
  amount,
  customerInfo
}) => {
  await storePaymentMethodInOMS({ orderNo, paymentToken, amount, customerInfo })

  // Release payment holds so OMS moves out of "Await Authorization"
  try {
    await apiClient.post('/invoke/changeOrder', {
      OrderNo: orderNo,
      EnterpriseCode: 'Aurora',
      DocumentType: '0001',
      Holds: {
        Hold: [{
          HoldType: 'PAYMENT_HOLD',     // payment authorization hold
          Status: 'RESOLVED',
          ReasonText: 'Razorpay authorization confirmed'
        }]
      }
    })
  } catch (e) {
    console.warn('Hold release failed (may not exist):', e?.response?.data || e.message)
  }

  return true
}